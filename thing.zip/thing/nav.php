<div class=nav style="position:relative">
    <?php if ($_SERVER["REQUEST_URI"] != "/thing/"){echo "<a href=\"/thing/\">Home</a>";} ?>
    <a href="/thing/text-change">Text Changer</a>
    <a href="/thing/text-to-number">Text to Numbers</a>
    <a href="/thing/javascript-tutorial">Javascript Tutorial</a>
    <a href="/thing/slide-puzzle">Slide Puzzle</a>
    <a href="/thing/chess">Chess</a>
    <a href="/thing/timer">Timer</a>
    <a href="/thing/patterns">Patterns</a>
</div>